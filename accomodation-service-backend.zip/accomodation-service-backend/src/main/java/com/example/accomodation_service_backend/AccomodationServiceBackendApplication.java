package com.example.accomodation_service_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccomodationServiceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccomodationServiceBackendApplication.class, args);
	}

}
