package com.example.accomodation_service_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccomodationServiceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
